<?php


/**
 * Admin menu (navigation)
 */
CroogoNav::add('sidebar', 'requests', array(
	'title' => 'Demandes',
	'icon' => 'folder',
	'url' => array(
		'admin' => true,
		'plugin' => 'request_managment',
		'controller' => 'requests',
		'action' => 'index',
	),
	'children' => array(),
));
CroogoNav::add('sidebar', 'meetings', array(
	'title' => 'Réunion',
	'icon' => 'calendar',
	'url' => '#',
	'children' => array(),
));
CroogoNav::add('sidebar', 'services', array(
	'title' => 'Services',
	'icon' => 'bookmark',
	'url' => '#',
	'children' => array(),
));
CroogoNav::add('sidebar', 'diplomats', array(
	'title' => 'Diplômes',
	'icon' => 'medall',
	'url' => '#',
	'children' => array(),
));
CroogoNav::add('sidebar', 'specialities', array(
	'title' => 'Spécialités',
	'icon' => 'view-list',
	'url' => '#',
	'children' => array(),
));