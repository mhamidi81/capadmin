<?php

App::uses('AppController', 'Controller');

class RequestManagmentAppController extends AppController {

}
