<?php

App::uses('AppModel', 'Model');

class RequestManagmentAppModel extends AppModel {
  public $tablePrefix = 'rqm_';
}
