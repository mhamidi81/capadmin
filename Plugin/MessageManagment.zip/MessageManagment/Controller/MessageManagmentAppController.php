<?php

App::uses('AppController', 'Controller');

class MessageManagmentAppController extends AppController {

}
