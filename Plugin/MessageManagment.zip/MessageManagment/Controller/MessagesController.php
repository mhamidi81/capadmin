<?php
App::uses('MessageManagmentAppController', 'MessageManagment.Controller');
/**
 * Messages Controller
 *
 * @property Message $Message
 * @property PaginatorComponent $Paginator
 */
class MessagesController extends MessageManagmentAppController {
//public $uses = array('Message', 'Recipient', 'Sender');
/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * beforeFilter method
 *
 * @return void
 */
function beforeFilter() { 

	parent::beforeFilter();

	$this->Security->csrfCheck = false;
	$this->Security->validatePost = false;
}

	
/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index($message_id = false) {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		//$userEmail = AuthComponent::user('id');

		$conditions = array(
			'email_to' => $userEmail,
			'mailbox' => 'inbox'
		); 
		
		if ($message_id){
			$conditions['Message.id'] = $message_id; 
		}
		
		$this->Paginator->settings = array(
			'conditions' => $conditions,
			'limit' => 10,
			'order' => 'Message.created DESC',
			'contain' => array(
				'Sender' => array(
					'fields' => array('first_name','last_name','email','image')
				)
			)
		);
		
		$messages = $this->Paginator->paginate('Message');
		
		$recipients = $this->Message->Recipient->find('first',array(
			'fields' => array('first_name','last_name','email','image'),
			'conditions' => array(
				'email' => $userEmail,
			),
			'recursive' => -1
		));
		// debug($recipients);die;
		$this->set(compact('messages','recipients'));

	}

/**
 * admin_add method
 *
 * @return void
 */
 	public function admin_add() {
		
		//$userEmail = AuthComponent::user('id');
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		$message = 'Echec d\'envoi de message.';
		$result = 'error';
		$errors=array();
		
		if( !empty($this->request['data']['Recipient']['id']) && !empty($this->request['data']['Message']['title']) ){
			
			foreach($this->request['data']['Recipient']['id'] as $i => $recipientId ){
				
				//messages enovoyes (boite de reception  du destinataire') 
				
				$inbox[$i]['Message']['email_to'] = $recipientId;
				$inbox[$i]['Message']['email_from'] = $userEmail;
				// $inbox[$i]['Message']['email_from'] = $userEmail;
				$inbox[$i]['Message']['title'] = $this->request['data']['Message']['title'];
				$inbox[$i]['Message']['body'] = $this->request['data']['Message']['body'];
				$inbox[$i]['Message']['mailbox'] = 'inbox';
				$inbox[$i]['Message']['status'] = 0;
				
			}

			if ($this->Message->saveAll($inbox)) {
				
				$message = 'Message envoyé';
				$result = 'success';
				
			} else {
				
				$errors = $this->Message->validationErrors;
			}
			
		}
		
		$data = array('message' =>  $message, 'result' => $result, 'errors' => $errors);
		
		$this->set('data', $data);
        $this->set('_serialize', 'data');
	}

/**
 * contact_admin method
 *
 * @return void
 */
 	public function admin_contact() {
		
		$userEmail = AuthComponent::user('email');
		
		$message = 'Echec d\'envoi de message.';
		
		$result = 'error';
		
		$errors = array();
		
		$destinataire = Configure::read('site_contact_email');
		
	
		if( (!empty($this->request['data']['Message']['title'])) && (!empty($this->request['data']['Message']['body']))){
			
			//messages enovoyes (boite de reception  du destinataire') 
			
			$inbox['Message']['email_to'] = $destinataire;
			$inbox['Message']['email_from'] = $userEmail;
			$inbox['Message']['title'] = $this->request['data']['Message']['title'];
			$inbox['Message']['body'] = $this->request['data']['Message']['body'];
			$inbox['Message']['mailbox'] = 'inbox';
			$inbox['Message']['status'] = 0;

			$this->Message->create();

			if ($this->Message->save($inbox)) {
				
				$message = 'Message envoyé';
				$result = 'success';
				
			} else {
				
				$errors = $this->Message->validationErrors;
			}
			
		}
		
		$data = array('message' =>  $message, 'result' => $result, 'errors' => $errors);
		
		$this->set('data', $data);
        $this->set('_serialize', 'data');
	}

/**
 * admin_edit method
 *
 * @return void
 */
	public function admin_edit() {

		$result = 'error';
		$message = 'error';
		
		if(isset($this->request['data']['id'])){
			
			$this->Message->id = $this->request['data']['id'];
			
			$valid = $this->Message->saveField('status' , 1 );
				if($valid){
					$result = 'success';
				}
		}

		$data = array('result' => $result, 'errors' => array());
		
		$this->set('data', $data);
        $this->set('_serialize', 'data');
	}

/**
 * admin_get_inbox method
 *
 * @return void
 */
	public function admin_get_inbox() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		
		$this->Paginator->settings = array(
				'conditions' => array(
					'email_to' => $userEmail,
					'mailbox' => 'inbox',
				),
				'limit' => 10,
				'contain' => array(
					'Sender' => array(
						'fields' => array('first_name','last_name','email','image')
					)
				),
				'order' => 'Message.created DESC'
			);
			
		$messages = $this->Paginator->paginate('Message');
		
		$recipients = $this->Message->Recipient->find('first',array(
			'fields' => array('first_name','last_name','email','image'),
			'conditions' => array(
				'email' => $userEmail,
			),
			'recursive' => -1
		));
		
		$this->set(compact('messages','recipients'));
	}

/**
 * admin_get_sentbox method
 *
 * @return void
 */
	public function admin_get_sentbox() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		
		$this->Paginator->settings = array(
				'conditions' => array(
					'email_from' => $userEmail,
					'mailbox' => 'sent',
				),
				'limit' => 10,
				'order' => 'Message.created DESC',
				'contain' => array(
					'Recipient' => array(
						'fields' => array('first_name','last_name','email','image')
					)
				),
				
			);
			
		$messages = $this->Paginator->paginate('Message');
		
		$this->set(compact('messages'));
	}

/**
 * admin_get_trash method
 *
 * @return void
 */
 
	public function admin_get_trash() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		
		$this->Paginator->settings = array(
				'conditions' => array(
					'OR' => array(
						array(
							'email_from' => $userEmail,
							'mailbox' => 'trash_sent',
						),
						array(
							'email_to' => $userEmail,
							'mailbox' => 'trash_inbox',
						)
					),
				),
				'limit' => 10,
				'order' => 'Message.created DESC',
				'contain' => array(
					'Recipient' => array(
						'fields' => array('first_name','last_name','email','image')
					),
					'Sender' => array(
						'fields' => array('first_name','last_name','email','image')
					)
				)
			);
			
		$messages = $this->Paginator->paginate('Message');
		
		$this->set(compact('messages'));
	}

/**
 * admin_search method
 *
 * @return void
 */
 
	public function admin_search() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));

		if(!empty($this->request['data']['q'])){
			
			$query = $this->request['data']['q'];
			
			$this->Paginator->settings = array(
				'conditions' => array(
					'OR' => array(
						'Message.email_to like ' => $userEmail,
						'Message.email_from like ' => $userEmail,
					),
					'OR' => array(
						'Message.title like ' => '%'.$query.'%',
						'Message.body like ' => '%'.$query.'%',
						'Recipient.email like ' => $query.'%',
					)
				),
				'limit' => 10,
				'order' => 'Message.created DESC',
				'contain' => array(
					'Recipient' => array(
						'fields' => array('first_name','last_name','email','image')
					),
					'Sender' => array(
						'fields' => array('first_name','last_name','email','image')
					)
				)
			);
			
			$messages = $this->Paginator->paginate('Message');
			
			$this->set(compact('messages'));
		}
	}

/**
 * admin_get_unread mail method
 *
 * @return void
 */
 
	public function admin_get_unread() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		
		$unreadMessages = $this->Message->find('count',array(
			'conditions' => array(
				'email_to' => $userEmail,
				'mailbox' => 'inbox',
				'status' => false,
			),
			'recursive' => -1
		));

		$this->set('data', $unreadMessages);
		$this->set('_serialize', 'data');
		
	}

/**
 * admin_get_users mail method
 *
 * @return void
 */
 
	public function admin_get_users() {

		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));
		
		$query = $this->request['data']['q']['term'];
		
		$users = $this->Message->Recipient->find('all',array(
			'fields' => array('Recipient.email as id', 'Recipient.email as text'),
			'conditions' => array(
				'OR' => array(
					'first_name like' => $query.'%',
					'last_name like' => $query.'%',
					'email like' => $query.'%',
				),
				'Recipient.email !=' => $userEmail
			),
			'recursive' => -1
		));
		
		$users = array('q' => $query, 'results' => Set::extract($users,'{n}.Recipient'));
		
		$this->set('data', $users);
		$this->set('_serialize', 'data');
	}

/**
 * admin_delete method
 *
 * @access public
 * @return void
 */
	public function admin_delete() {
		
		$userEmail = $this->Message->Recipient->field('email', array('id' => AuthComponent::user('id')));

		$result = 'error';
		$message = 'Echec de la suppression du message';
		
		if(isset($this->request['data']['id'])){

			$mailboxMessage = $this->Message->find('first', array(
				'fields' => 'mailbox',
				'conditions' => array(
					'Message.id' => $this->request['data']['id'],
					'OR' => array(
						array(
							'email_from' => $userEmail,
						),
						array(
							'email_to' => $userEmail,
						),
					),
				),
				'recursive' => -1
			));
			
			$this->Message->id = $this->request['data']['id'];
			
			
			if ( $mailboxMessage['Message']['mailbox'] == 'sent' ) {
				
				$valid = $this->Message->saveField('mailbox' , 'trash_sent' );
				if ($valid) $result = 'success';
				
			}elseif ( $mailboxMessage['Message']['mailbox'] == 'inbox' ){
				
				$valid = $this->Message->saveField('mailbox' , 'trash_inbox' );
				if ($valid) $result = 'success';
				
			}else {
				
				$valid = $this->Message->delete();
				if ($valid) $result = 'success';
				
			}
		}
		
		if ($result == 'success') $message = 'Message supprimé';
		$data = array('result' => $result, 'message' => $message);

		$this->set('data', $data);
		$this->set('_serialize', 'data');

	}
}
